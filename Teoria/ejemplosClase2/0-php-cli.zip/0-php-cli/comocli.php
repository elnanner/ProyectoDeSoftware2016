<?php 
echo "Hola $argv[1]\n";
?>
